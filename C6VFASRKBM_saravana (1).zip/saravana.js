// js/script.js

function initMap() {
    // The location of the travel agency
    const agencyLocation = {
        lat: 40.7128,
        lng: -74.0060
    }; // Example: New York City
    // The map, centered at the travel agency
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 14,
        center: agencyLocation,
    });
    // The marker, positioned at the travel agency
    const marker = new google.maps.Marker({
        position: agencyLocation,
        map: map,
    });
}